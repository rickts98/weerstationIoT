#include "reader.h"

int (*available)();

char (*read)();

char (*peek)();

void initParser(int (*availableFunc)(), char (*readFunc)(),

                char (*peekFunc)()) {

  available = availableFunc;

  read = readFunc;

  peek = peekFunc;
}
